TEST_IMAGE_PATH = "./data/signed_image.jpeg"
TEST_PDF_PATH = "./data/signed_file.pdf"
TEST_TIF_PATH = "./data/signed_image.tif"